package model;

public interface expires {
	boolean isExpired();
	//a product that can expire will implement this interface
}
