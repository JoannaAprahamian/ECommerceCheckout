package model;

public class customer {
	double balance;
	
	public customer(int balance){
		this.balance = balance;
	}
}
